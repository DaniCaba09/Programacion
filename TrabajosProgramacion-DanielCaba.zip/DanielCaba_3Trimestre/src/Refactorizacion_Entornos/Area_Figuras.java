package Refactorizacion_Entornos;

import java.util.Scanner;

public class Area_Figuras {
	
	
	public static void main(String[] args) {Calculos_Figuras Area = new Calculos_Figuras();
	
	Scanner sc = new Scanner(System.in);
	
	double lado, altura, base, radio; //Variables de tipo double
	
	System.out.print("Ingrese un valor numerico del lado para el area de la figura ="); //Pedimos por teclado
	lado = sc.nextDouble();
	
	System.out.print("Ingrese un valor numerico de la base para el area de la figura =");	//Pedimos por teclado
	base = sc.nextDouble();
	
	System.out.print("Ingrese un valor numerico de la altura para el area de la figura =");	//Pedimos por teclado
	altura = sc.nextDouble();
	
	System.out.print("Ingrese un valor numerico del radio para el area de la figura ="); //Pedimos por teclado
	radio = sc.nextDouble(); 
	
    
	        /*
	         * En las siguientes lineas invocamos los diferentes métodos que
	         * trae nuestro objeto "Area" y mostramos el resultado por consola.
	         */
	System.out.println("------------------------------------------");
	System.out.println("Resultado del area de tu Cuadrado --> " + Area.cuadrado (lado)); //Resultado del area del cuadrado
	
	System.out.println("Resultado del area de tu Triangulo -->" + Area.triangulo(base, altura)); //Resultado del area del triangulo
	
	System.out.println("Resultado del area de tu Rectangulo -->" + Area.rectangulo(base, altura)); //Resultado del area del rectangulo
	
	System.out.println("Resultado del area de tu Circulo -->" + Area.circulo(radio)); //Resultado del area del circulo
	
	}
	    
}

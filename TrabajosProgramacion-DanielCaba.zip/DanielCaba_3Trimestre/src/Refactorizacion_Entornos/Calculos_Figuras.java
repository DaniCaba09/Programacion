package Refactorizacion_Entornos;

public class Calculos_Figuras {
	
	
	public double cuadrado (double lado){
		 return (lado * lado);
		 
	}
	public double rectangulo(double base,double altura) {
		return ( base * altura);
		
		}
	public double triangulo(double base, double altura) {
		return (base * altura)/2;
		
		}
	public double circulo(double radio) {
		return (3.14*(radio*radio));
		
		}

}


package DepuraciónCódigoEntornos;

import java.util.ArrayList;

public class ARRAYLIST {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Integer> Pablo = new ArrayList();
		
		Pablo.add(8758554);
		
		Pablo.add(8758554);
		Pablo.add(8758554);
		Pablo.add(8758554);
		System.out.println(Pablo);
	
	
	for (int i=0;i<5;i++) {
		System.out.println("si");
	}
	}
}

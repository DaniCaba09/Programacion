
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import CONEXION.Conexion;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.Button;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
import javax.swing.JPasswordField;

public class IniciarSesion extends JFrame {

	private JPanel contentPane;
	private JTextField correoSesion;
	private JTextField UsuarioSesion;
	static IniciarSesion vS;
	private JPasswordField ContraseñaSesion;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					vS = new IniciarSesion();
					vS.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public IniciarSesion() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(222, 184, 135));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		ContraseñaSesion = new JPasswordField();
		ContraseñaSesion.setBounds(178, 167, 208, 20);
		contentPane.add(ContraseñaSesion);
		
		JLabel TituloIniciarSesion = new JLabel("INICIAR SESIÓN");
		TituloIniciarSesion.setBackground(new Color(135, 206, 235));
		TituloIniciarSesion.setHorizontalAlignment(SwingConstants.CENTER);
		TituloIniciarSesion.setForeground(new Color(175, 238, 238));
		TituloIniciarSesion.setFont(new Font("Impact", Font.PLAIN, 30));
		TituloIniciarSesion.setBounds(109, 26, 208, 27);
		contentPane.add(TituloIniciarSesion);
		
		JLabel lblNewLabel_1 = new JLabel("Correo Electrónico:");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Cambria Math", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(35, 84, 138, 27);
		contentPane.add(lblNewLabel_1);
		
		correoSesion = new JTextField();
		correoSesion.setBounds(178, 86, 208, 20);
		contentPane.add(correoSesion);
		correoSesion.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Nombre de Usuario:");
		lblNewLabel_1_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1_1.setFont(new Font("Cambria Math", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(35, 127, 138, 27);
		contentPane.add(lblNewLabel_1_1);
		
		UsuarioSesion = new JTextField();
		UsuarioSesion.setColumns(10);
		UsuarioSesion.setBounds(178, 129, 208, 20);
		contentPane.add(UsuarioSesion);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Contraseña:");
		lblNewLabel_1_1_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1_1_1.setFont(new Font("Cambria Math", Font.PLAIN, 15));
		lblNewLabel_1_1_1.setBounds(35, 165, 138, 27);
		contentPane.add(lblNewLabel_1_1_1);
		
		Button Comenzar = new Button("COMENZAR");
		Comenzar.setForeground(new Color(139, 69, 19));
		Comenzar.setFont(new Font("Georgia", Font.BOLD, 15));
		Comenzar.setBackground(new Color(250, 250, 210));
		Comenzar.setBounds(162, 216, 107, 35);
		contentPane.add(Comenzar);
		Comenzar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(correoSesion.getText().equals("admin@")  || UsuarioSesion.getText().equals("admin")  || ContraseñaSesion.getText().equals("admin.") ) {
					
					int confirmar = JOptionPane.showConfirmDialog(Comenzar, "¿Estas seguro de que deseas ir a la ventana de Administrador?");
					
					if(confirmar == 0) {
					
					JFrame IniciarSesion= new Borrar();
					IniciarSesion.setVisible(true);
                    setVisible(false);
					}
				}
				
				else {
					
				
				
				if (correoSesion.getText().length()==0 || UsuarioSesion.getText().length()==0 || ContraseñaSesion.getText().length()==0) {
					JOptionPane.showMessageDialog(contentPane, "Hace falta informacion huevos", "Inicio de Sesion", JOptionPane.ERROR_MESSAGE);
					
				}else {
					
					ConsultaDatos consultas = new ConsultaDatos();
					
					
					if(consultas.login(correoSesion.getText(), UsuarioSesion.getText(), ContraseñaSesion.getText())) {
						
						JOptionPane.showMessageDialog(contentPane, "Ha iniciado sesión correctamente", "Registro de Usuario", JOptionPane.INFORMATION_MESSAGE);
						
						JFrame IniciarSesion= new Comenzar();
						IniciarSesion.setVisible(true);
	                    setVisible(false);
					}
					
					else {
						JOptionPane.showMessageDialog(contentPane, "Credenciales Incorrectas.", "Registro de Usuario", JOptionPane.ERROR_MESSAGE);
					}
					
			}}}
		});
		
		JButton MostrarContraseña = new JButton("Mostrar Contraseña");
		MostrarContraseña.addActionListener(new ActionListener() {
			
				boolean activado= false;
	            public void actionPerformed(ActionEvent e) {

	                if(!activado) {
	                    activado=true;
	                    ContraseñaSesion.setEchoChar((char)(0));


	                }else {
	                    activado=false;
	                    ContraseñaSesion.setEchoChar('●');

	                }


	            }
	        });
		MostrarContraseña.setForeground(new Color(64, 224, 208));
		MostrarContraseña.setBounds(235, 190, 151, 20);
		contentPane.add(MostrarContraseña);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setIcon(new ImageIcon(IniciarSesion.class.getResource("/ImagenesLogin/football.gif")));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_2.setBounds(0, 0, 434, 261);
		contentPane.add(lblNewLabel_2);
		
		
		
	}

}


import java.awt.Component;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import CONEXION.Conexion;

public class ConsultaDatos {
	
	public static Component contentPane;
	String Usuario;
	String Nombre;
	String Correo;
	String Telefono;
	String Contraseña;
	
	
	public static void registrar (String Usuario, String Correo, String Telefono, String Contraseña) {
		
				
				Conexion conexion = new Conexion();
				Connection cn = null;
				ResultSet rs = null;
				PreparedStatement stm2 = null;
				try {
					cn = conexion.conectar();
					stm2 = cn.prepareStatement("INSERT INTO usuario(Nombre,Correo_Electronico,Telefono, Contraseña) VALUES (?,?,?,?)");
					stm2.setString(1 , Usuario);
					stm2.setString(2 , Correo);
					stm2.setString(3 , Telefono);
					stm2.setString(4, Contraseña);
					
					stm2.executeUpdate();
					
					
				} catch (SQLException e1) {
					e1.printStackTrace();
					
				
				} finally {
					try {
						if (rs!= null) {
							rs.close();
						}
						
						if (stm2 != null) {
							stm2.close();
						}
						
						if (cn != null) {
							cn.close();
						}
					} catch (Exception e2) {
						e2.printStackTrace();
					}
				}
				
				
	}
	
	public static boolean login (String Correoin, String Usuarioin, String Contraseñain) {
		
		
			
			Conexion conexion = new Conexion();
			Connection cn = null;
			Statement stm = null;
			ResultSet rs = null;
			PreparedStatement pst = null;
			boolean correcto=false;
			
			try {
				cn = conexion.conectar();
				stm = cn.createStatement();
				pst = cn.prepareStatement("SELECT * FROM usuario WHERE correo_electronico = ? AND Nombre = ? AND Contraseña = ?");
				pst.setString(1, Correoin);
				pst.setString(2, Usuarioin);
				pst.setString(3, Contraseñain);
				rs = pst.executeQuery();
				
				while (rs.next()) {
					String Nombre = rs.getString(1);
					String Correo = rs.getString(2);
					String Telefono = rs.getString(3);
					String Contraseña = rs.getString(4);
					
					if(Correo.equals(Correoin) && Nombre.equals(Usuarioin) && Contraseña.equals(Contraseñain)) {
						correcto=true;
					}
					
				}
				
			} catch (SQLException e1) {
				e1.printStackTrace();
				
			} finally {
				try {
					if (rs!= null) {
						rs.close();
					}
					
					if (stm != null) {
						stm.close();
					}
					
					if (cn != null) {
						cn.close();
					}
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
			
	return correcto;
	}
	
	public static void MostrarUsuarios (JTable table) {
		
		Conexion conexion = new Conexion();
		Connection cn = null;
		Statement stm = null;
		ResultSet rs = null;
		DefaultTableModel Modelo = (DefaultTableModel) table.getModel();
		
		Modelo.getDataVector().removeAllElements();
		
		try {
			cn = conexion.conectar();
			stm = cn.createStatement();
			rs = stm.executeQuery("SELECT * FROM usuario");
			
			while (rs.next()) {
				String Nombre = rs.getString(1);
				String Correo_Electronico = rs.getString(2);
				String Telefono = rs.getString(3);
				String Contraseña = rs.getString(4);
				
				String [] filas = {Nombre, Correo_Electronico, Telefono, Contraseña};
				
				Modelo.addRow(filas);
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			
		} finally {
			try {
				if (rs!= null) {
					rs.close();
				}
				
				if (stm != null) {
					stm.close();
				}
				
				if (cn != null) {
					cn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static void Borrar (String Introducir_usuario) {
		
		Conexion conexion = new Conexion();
		Connection cn = null;
		Statement stm = null;
		ResultSet rs = null;
		
		try {
			cn = conexion.conectar();
			PreparedStatement stm2 = cn.prepareStatement("DELETE FROM usuario  WHERE Nombre = ?");
			stm2.setString(1 , Introducir_usuario);
			
			stm2.executeUpdate();
			
		} catch (SQLException e1) {
			e1.printStackTrace();
			
		} finally {
			try {
				if (rs!= null) {
					rs.close();
				}
				
				if (stm != null) {
					stm.close();
				}
				
				if (cn != null) {
					cn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
		}
		}
	};
	
}


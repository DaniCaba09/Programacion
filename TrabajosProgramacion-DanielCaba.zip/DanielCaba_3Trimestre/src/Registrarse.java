import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import CONEXION.Conexion;

import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Button;
import java.awt.SystemColor;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class Registrarse extends JFrame {
	private JTextField Usuario;
	private JPasswordField Contraseña;
	private JLabel Texto_Correo;
	private JTextField Correo;
	private JLabel Texto_Telefono;
	private JTextField Telefono;
	private JLabel Texto_Contraseña;
	static Registrarse vP;
	private JLabel lblNewLabel_6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					vP = new Registrarse();
					vP.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Registrarse() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(550, 400, 550, 500);
		JPanel contentPane = new JPanel();
		contentPane.setBackground(SystemColor.info);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("REGISTRAR NUEVO USUARIO");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 140, 0));
		lblNewLabel.setBounds(94, 23, 345, 28);
		lblNewLabel.setLabelFor(this);
		lblNewLabel.setBackground(new Color(64, 128, 128));
		lblNewLabel.setFont(new Font("Impact", Font.PLAIN, 30));
		contentPane.add(lblNewLabel);
		
		JLabel Texto_Nombre = new JLabel("Nombre:");
		Texto_Nombre.setForeground(new Color(240, 248, 255));
		Texto_Nombre.setBounds(72, 94, 53, 35);
		contentPane.add(Texto_Nombre);
		
		Usuario = new JTextField();
		Usuario.setBounds(152, 101, 262, 20);
		contentPane.add(Usuario);
		Usuario.setColumns(10);
		
		Contraseña = new JPasswordField();
		Contraseña.setBounds(152, 290, 262, 20);
		contentPane.add(Contraseña);
		
		Texto_Correo = new JLabel("Correo Electrónico:");
		Texto_Correo.setForeground(new Color(240, 248, 255));
		Texto_Correo.setBounds(70, 171, 120, 14);
		contentPane.add(Texto_Correo);
		
		Correo = new JTextField();
		Correo.setColumns(10);
		Correo.setBounds(200, 168, 214, 20);
		contentPane.add(Correo);
		
		Texto_Telefono = new JLabel("Teléfono:");
		Texto_Telefono.setForeground(new Color(240, 248, 255));
		Texto_Telefono.setBounds(70, 233, 70, 14);
		contentPane.add(Texto_Telefono);
		
		Telefono = new JTextField();
		Telefono.setColumns(10);
		Telefono.setBounds(152, 230, 262, 20);
		contentPane.add(Telefono);
		
		
		Texto_Contraseña = new JLabel("Contraseña:");
		Texto_Contraseña.setForeground(new Color(240, 248, 255));
		Texto_Contraseña.setBounds(70, 293, 72, 14);
		contentPane.add(Texto_Contraseña);
		
		Button Registrarse = new Button("Registrarse");
		Registrarse.setFont(new Font("Impact", Font.BOLD | Font.ITALIC, 18));
		Registrarse.setBackground(new Color(255, 165, 0));
		Registrarse.setBounds(185, 360, 171, 48);
		contentPane.add(Registrarse);
		Registrarse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (Usuario.getText().length()==0  || Correo.getText().length()==0 || Telefono.getText().length()==0 || Contraseña.getText().length() == 0) {
					JOptionPane.showMessageDialog(contentPane, "Hace falta rellenar los demás campos, por favor.", "Registro de Usuario", JOptionPane.ERROR_MESSAGE);
					
				}
				
				else {
					
				if(Correo.getText().equals("admin@")  || Usuario.getText().equals("admin")  || Contraseña.getText().equals("admin.")) {
					JOptionPane.showMessageDialog(contentPane, "Esto es imposible.Disculpe.", "Registro de Usuario", JOptionPane.ERROR_MESSAGE);
				}else {
					
				if (!Correo.getText().contains("@")){
					JOptionPane.showMessageDialog(contentPane, "Pon un '@' en el apartado del correo electrónico, por favor.", "Registro de Usuario", JOptionPane.INFORMATION_MESSAGE);
					
				}else {
						if (!Contraseña.getText().contains(".")){
							JOptionPane.showMessageDialog(contentPane, "Pon un '.' en el apartado de la contraseña, por favor.", "Registro de Usuario", JOptionPane.INFORMATION_MESSAGE);
						}
				
					else {
					
					int confirmar = JOptionPane.showConfirmDialog(Registrarse, "¿Estas seguro de que deseas registrarte en nuestra web?");
					
					if(confirmar == 0) {
						
						
					ConsultaDatos Registro = new ConsultaDatos ();
						
					Registro.registrar(Usuario.getText(), Correo.getText(), Telefono.getText(), Contraseña.getText());;
						
					
					JOptionPane.showMessageDialog(contentPane, "Genial. Se ha registrado correctamente", "Registro de Usuario", JOptionPane.INFORMATION_MESSAGE);
			
					JFrame IniciarSesion= new Comenzar();
					IniciarSesion.setVisible(true);
                    setVisible(false);
                    
					} else {
						JOptionPane.showMessageDialog(contentPane, "Okey, espero tu confirmación", "Registro de Usuario", JOptionPane.INFORMATION_MESSAGE);
						
						
						
						
			}}}}}
			}});
		
		JButton MostrarContraseña = new JButton("Mostrar Contraseña");
		MostrarContraseña.setBackground(new Color(224, 255, 255));
		MostrarContraseña.addActionListener(new ActionListener() {
			boolean activado= false;
            public void actionPerformed(ActionEvent e) {

                if(!activado) {
                    activado=true;
                    Contraseña.setEchoChar((char)(0));


                }else {
                    activado=false;
                    Contraseña.setEchoChar('●');
                    
                    
                }

            }
        });
		MostrarContraseña.setForeground(new Color(255, 127, 80));
		MostrarContraseña.setFont(new Font("Mongolian Baiti", Font.BOLD, 13));
		MostrarContraseña.setBounds(258, 321, 156, 23);
		contentPane.add(MostrarContraseña);
		
		JButton btnIniciarSesion = new JButton("Iniciar Sesión");
		btnIniciarSesion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame frame= new IniciarSesion();
				frame.setVisible(true);
				vP.setVisible(false);
			}
		});
		
		
		btnIniciarSesion.setBackground(new Color(224, 255, 255));
		btnIniciarSesion.setFont(new Font("Impact", Font.ITALIC, 14));
		btnIniciarSesion.setBounds(383, 414, 120, 23);
		contentPane.add(btnIniciarSesion);
		
		lblNewLabel_6 = new JLabel("New label");
		lblNewLabel_6.setIcon(new ImageIcon("C:\\Users\\dcs00\\eclipse-workspace\\DanielCaba_3Trimestre\\src\\ImagenesLogin\\550393.jpg"));
		lblNewLabel_6.setBounds(-356, -30, 1161, 517);
		contentPane.add(lblNewLabel_6);
		
		
		
	}
}

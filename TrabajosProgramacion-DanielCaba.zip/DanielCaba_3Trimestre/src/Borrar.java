import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.SystemColor;
import javax.swing.JTable;
import javax.swing.border.EtchedBorder;
import javax.swing.border.MatteBorder;

import CONEXION.Conexion;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;

public class Borrar extends JFrame {

	private JPanel contentPane;
	private JTextField Introducir_usuario;
	private JButton btnBORRAR;
	private JPanel panel;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Borrar frame = new Borrar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Borrar() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 615, 406);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Introducir_usuario = new JTextField();
		Introducir_usuario.setBackground(UIManager.getColor("CheckBox.light"));
		Introducir_usuario.setForeground(new Color(255, 215, 0));
		Introducir_usuario.setBounds(108, 69, 393, 27);
		contentPane.add(Introducir_usuario);
		Introducir_usuario.setColumns(10);
		
		btnBORRAR = new JButton("BORRAR");
		btnBORRAR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ConsultaDatos Borrar = new ConsultaDatos ();
				
				int confirmar = JOptionPane.showConfirmDialog(contentPane, "¿Estas seguro de que deseas borrar este usuario?");
				
				if(confirmar == 0) {
					Borrar.Borrar(Introducir_usuario.getText());
					
					 JOptionPane.showMessageDialog(contentPane, "Usuario Borrado con éxito.", "Borrar Usuario", JOptionPane.INFORMATION_MESSAGE);
				}
				else {
					JOptionPane.showMessageDialog(contentPane, "Borrado Fallido.",  "Borrar Usuario", JOptionPane.ERROR_MESSAGE);
				}
				
			}
		});
		btnBORRAR.setBackground(new Color(255, 248, 220));
		btnBORRAR.setForeground(new Color(255, 215, 0));
		btnBORRAR.setFont(new Font("Monospaced", Font.BOLD, 20));
		btnBORRAR.setBounds(221, 305, 149, 40);
		contentPane.add(btnBORRAR);
		
		panel = new JPanel();
		panel.setBackground(new Color(75, 0, 130));
		panel.setBounds(0, 0, 599, 367);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel Texto_queborrar = new JLabel("INDICA EL USUARIO QUE QUIERES BORRAR");
		Texto_queborrar.setBounds(48, 21, 519, 40);
		panel.add(Texto_queborrar);
		Texto_queborrar.setBackground(new Color(255, 215, 0));
		Texto_queborrar.setForeground(new Color(255, 215, 0));
		Texto_queborrar.setFont(new Font("NSimSun", Font.BOLD, 26));
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nombre", "Correo_Electronico", "Telefono", "Contrase\u00F1a"
			}
		));
		table.setBounds(33, 112, 544, 180);
		panel.add(table);
		table.setBackground(new Color(224, 255, 255));
		table.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		
		
		ConsultaDatos consulta = new ConsultaDatos ();
		consulta.MostrarUsuarios(table);
		
		
	}
}

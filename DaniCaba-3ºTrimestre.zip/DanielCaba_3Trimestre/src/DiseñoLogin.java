import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Button;
import java.awt.SystemColor;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class DiseñoLogin extends JFrame {
	private JTextField Usuario;
	private JPasswordField Contraseña;
	private JTextField Apellidos;
	private JLabel lblNewLabel_3;
	private JTextField Correo;
	private JLabel lblNewLabel_4;
	private JTextField Telefono;
	private JLabel lblNewLabel_5;
	static DiseñoLogin vP;
	static DiseñoLogin vS;
	private JLabel lblNewLabel_6;
	static DiseñoLogin vP1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					vP = new DiseñoLogin();
					vP.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DiseñoLogin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(550, 400, 550, 500);
		JPanel contentPane = new JPanel();
		contentPane.setBackground(SystemColor.info);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("REGISTRAR NUEVO USUARIO");
		lblNewLabel.setForeground(new Color(255, 140, 0));
		lblNewLabel.setBounds(94, 23, 345, 28);
		lblNewLabel.setLabelFor(this);
		lblNewLabel.setBackground(new Color(64, 128, 128));
		lblNewLabel.setFont(new Font("Lucida Sans Unicode", Font.BOLD, 23));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Nombre:");
		lblNewLabel_1.setForeground(new Color(240, 248, 255));
		lblNewLabel_1.setBounds(70, 79, 53, 35);
		contentPane.add(lblNewLabel_1);
		
		Usuario = new JTextField();
		Usuario.setBounds(133, 86, 281, 20);
		contentPane.add(Usuario);
		Usuario.setColumns(10);
		
		Contraseña = new JPasswordField();
		Contraseña.setBounds(152, 290, 262, 20);
		contentPane.add(Contraseña);
		
		JLabel lblNewLabel_2 = new JLabel("Apellidos:");
		lblNewLabel_2.setForeground(new Color(240, 248, 255));
		lblNewLabel_2.setBounds(72, 141, 70, 14);
		contentPane.add(lblNewLabel_2);
		
		Apellidos = new JTextField();
		Apellidos.setColumns(10);
		Apellidos.setBounds(133, 138, 281, 20);
		contentPane.add(Apellidos);
		
		lblNewLabel_3 = new JLabel("Correo Electrónico:");
		lblNewLabel_3.setForeground(new Color(240, 248, 255));
		lblNewLabel_3.setBounds(70, 187, 120, 14);
		contentPane.add(lblNewLabel_3);
		
		Correo = new JTextField();
		Correo.setColumns(10);
		Correo.setBounds(200, 184, 214, 20);
		contentPane.add(Correo);
		
		lblNewLabel_4 = new JLabel("Teléfono:");
		lblNewLabel_4.setForeground(new Color(240, 248, 255));
		lblNewLabel_4.setBounds(70, 244, 92, 14);
		contentPane.add(lblNewLabel_4);
		
		Telefono = new JTextField();
		Telefono.setColumns(10);
		Telefono.setBounds(133, 241, 281, 20);
		contentPane.add(Telefono);
		
		lblNewLabel_5 = new JLabel("Contraseña:");
		lblNewLabel_5.setForeground(new Color(240, 248, 255));
		lblNewLabel_5.setBounds(70, 293, 72, 14);
		contentPane.add(lblNewLabel_5);
		
		Button Registrarse = new Button("Registrarse");
		Registrarse.setFont(new Font("Impact", Font.PLAIN, 18));
		Registrarse.setBackground(new Color(255, 165, 0));
		Registrarse.setBounds(220, 360, 107, 48);
		contentPane.add(Registrarse);
		Registrarse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (Usuario.getText().length()!=0) {
					Usuario.setVisible(true);
				}
			
			JOptionPane.showMessageDialog(contentPane, "Se ha registrado en la web correctamente", "Registro de Usuario", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		
		JButton MostrarContraseña = new JButton("Mostrar Contraseña");
		MostrarContraseña.addActionListener(new ActionListener() {
			boolean activado= false;
            public void actionPerformed(ActionEvent e) {

                if(!activado) {
                    activado=true;
                    Contraseña.setEchoChar((char)(0));


                }else {
                    activado=false;
                    Contraseña.setEchoChar('●');

                }


            }
        });
		MostrarContraseña.setForeground(SystemColor.textHighlight);
		MostrarContraseña.setFont(new Font("Tahoma", Font.PLAIN, 13));
		MostrarContraseña.setBounds(258, 321, 156, 23);
		contentPane.add(MostrarContraseña);
		
		JButton btnIniciarSesion = new JButton("Iniciar Sesión");
		btnIniciarSesion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame frame= new IniciarSesion();
				frame.setVisible(true);
				vP.setVisible(false);
			}
		});
		btnIniciarSesion.setBackground(new Color(224, 255, 255));
		btnIniciarSesion.setFont(new Font("Impact", Font.ITALIC, 14));
		btnIniciarSesion.setBounds(383, 414, 120, 23);
		contentPane.add(btnIniciarSesion);
		
		lblNewLabel_6 = new JLabel("New label");
		lblNewLabel_6.setIcon(new ImageIcon("C:\\Users\\dcs00\\eclipse-workspace\\DanielCaba_3Trimestre\\src\\ImagenesLogin\\550393.jpg"));
		lblNewLabel_6.setBounds(-356, -30, 1161, 517);
		contentPane.add(lblNewLabel_6);
		
		
		
	}
}

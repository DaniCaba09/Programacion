import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.UIManager;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import javax.swing.ImageIcon;

public class Comenzar extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Comenzar frame = new Comenzar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Comenzar() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 102, 102));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel WEB = new JLabel("HAS ACCEDIDO A LA WEB ");
		WEB.setForeground(new Color(255, 255, 51));
		WEB.setBackground(Color.BLUE);
		WEB.setFont(new Font("Impact", Font.BOLD | Font.ITALIC, 29));
		WEB.setHorizontalAlignment(SwingConstants.CENTER);
		WEB.setBounds(10, 116, 414, 95);
		contentPane.add(WEB);
		
		JPanel panel = new JPanel();
		panel.setBounds(242, 16, 1, 1);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel enhorabuena = new JLabel("ENHORABUENA JEFE");
		enhorabuena.setForeground(new Color(0, 255, 255));
		enhorabuena.setFont(new Font("Impact", Font.BOLD | Font.ITALIC, 29));
		enhorabuena.setHorizontalAlignment(SwingConstants.CENTER);
		enhorabuena.setBounds(69, 52, 304, 55);
		contentPane.add(enhorabuena);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\dcs00\\eclipse-workspace\\DanielCaba_3Trimestre\\src\\ImagenesLogin\\inazuma-eleven-ina11.gif"));
		lblNewLabel_1.setBounds(0, 0, 434, 261);
		contentPane.add(lblNewLabel_1);
	}
}
